# Nawab Sales App — Demo v1

Android Studio project for the first Nawab Sales demo.

## Included
- Bengali UI
- Customer/shop entry
- Demo product catalogue
- Quantity + price calculation
- Discount and grand total
- Save orders locally on the phone
- Order history
- Print order using Android Print service
- Share order as text
- Nawab logo

## Build
Open this folder in Android Studio. Let Gradle sync, then choose **Build > Build APK(s)**.
The generated debug APK is normally under `app/build/outputs/apk/debug/`.

The project intentionally uses only Android platform APIs (no third-party runtime libraries), so it is easy to customize.
