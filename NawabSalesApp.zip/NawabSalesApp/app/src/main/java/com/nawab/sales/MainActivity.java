package com.nawab.sales;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.pdf.PdfDocument;
import android.print.*;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, productList, historyList; EditText customer, discount; TextView totalView, emptyHistory;
    final ArrayList<ProductRow> rows = new ArrayList<>();
    final ArrayList<String> orders = new ArrayList<>();
    android.content.SharedPreferences prefs;
    int green=Color.rgb(6,76,59), gold=Color.rgb(214,165,44), dark=Color.rgb(23,33,27);

    static class ProductRow { String name; double price; EditText qty; TextView lineTotal; ProductRow(String n,double p){name=n;price=p;} }

    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("nawab",0); loadOrders(); showHome();}
    TextView tv(String s,int sp){ TextView t=new TextView(this); t.setText(s); t.setTextSize(sp); t.setTextColor(dark); t.setPadding(16,12,16,12); return t; }
    Button btn(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    void base(){ root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(Color.rgb(247,249,247)); setContentView(root); }
    void header(String title){ LinearLayout h=new LinearLayout(this); h.setGravity(Gravity.CENTER_VERTICAL); h.setPadding(10,8,10,8); h.setBackgroundColor(green);
        TextView t=tv(title,21); t.setTextColor(Color.WHITE); t.setTypeface(null,1); h.addView(t,new LinearLayout.LayoutParams(0,70,1));
        Button home=btn("হোম"); home.setTextColor(Color.WHITE); home.setBackgroundColor(green); home.setOnClickListener(v->showHome()); h.addView(home,new LinearLayout.LayoutParams(70,70)); root.addView(h); }
    void showHome(){ base();
        ImageView logo=new ImageView(this); logo.setImageResource(com.nawab.sales.R.drawable.nawab_logo); logo.setAdjustViewBounds(true); logo.setPadding(24,16,24,8); root.addView(logo,new LinearLayout.LayoutParams(-1,280));
        TextView title=tv("নবাব Sales App",28); title.setTextColor(green); title.setGravity(Gravity.CENTER); title.setTypeface(null,1); root.addView(title);
        TextView sub=tv("Sales Order Management • Demo v1",15); sub.setGravity(Gravity.CENTER); root.addView(sub);
        Button order=btn("🛒  নতুন অর্ডার"); order.setOnClickListener(v->showOrder()); root.addView(order,new LinearLayout.LayoutParams(-1,60));
        Button hist=btn("📋  অর্ডার হিস্ট্রি"); hist.setOnClickListener(v->showHistory()); root.addView(hist,new LinearLayout.LayoutParams(-1,60));
        TextView info=tv("এই ডেমোতে আপনার পণ্যের বদলে নমুনা পণ্য আছে। পরে আসল পণ্য/দাম বসানো যাবে।",14); info.setGravity(Gravity.CENTER); root.addView(info);
    }
    void showOrder(){ base(); header("নতুন অর্ডার"); ScrollView sv=new ScrollView(this); LinearLayout body=new LinearLayout(this); body.setOrientation(LinearLayout.VERTICAL); body.setPadding(12,10,12,20);
        customer=new EditText(this); customer.setHint("দোকান / কাস্টমারের নাম"); body.addView(customer,new LinearLayout.LayoutParams(-1,60));
        TextView ph=tv("পণ্য নির্বাচন ও পরিমাণ",18); ph.setTypeface(null,1); body.addView(ph); productList=new LinearLayout(this); productList.setOrientation(LinearLayout.VERTICAL); body.addView(productList);
        String[][] p={{"চাল ২৫ কেজি","1200"},{"ডাল ৫ কেজি","650"},{"সয়াবিন তেল ৫ লিটার","900"},{"চিনি ৫ কেজি","600"},{"মসলা প্যাক","250"}};
        for(String[] x:p) addProduct(x[0],Double.parseDouble(x[1]));
        discount=new EditText(this); discount.setHint("Discount (৳)"); discount.setInputType(2|8192); body.addView(discount,new LinearLayout.LayoutParams(-1,60));
        totalView=tv("মোট: ৳0.00",22); totalView.setTypeface(null,1); totalView.setTextColor(green); body.addView(totalView);
        Button save=btn("✅  অর্ডার সংরক্ষণ করুন"); save.setOnClickListener(v->saveOrder()); body.addView(save,new LinearLayout.LayoutParams(-1,62));
        sv.addView(body); root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); }
    void addProduct(String name,double price){ LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(4,4,4,4);
        TextView n=tv(name+"\n৳"+String.format(Locale.US,"%.2f",price),15); row.addView(n,new LinearLayout.LayoutParams(0,62,1));
        EditText q=new EditText(this); q.setText("0"); q.setGravity(Gravity.CENTER); q.setInputType(2); row.addView(q,new LinearLayout.LayoutParams(70,60));
        TextView lt=tv("৳0",15); lt.setGravity(Gravity.CENTER); row.addView(lt,new LinearLayout.LayoutParams(90,60)); productList.addView(row);
        ProductRow pr=new ProductRow(name,price); pr.qty=q; pr.lineTotal=lt; rows.add(pr); q.setOnFocusChangeListener((v,f)->recalc()); q.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){} public void onTextChanged(CharSequence s,int st,int b,int c){recalc();} public void afterTextChanged(android.text.Editable e){}}); }
    double recalc(){ double total=0; for(ProductRow r:rows){int q=0; try{q=Integer.parseInt(r.qty.getText().toString());}catch(Exception e){} double x=q*r.price; total+=x; r.lineTotal.setText("৳"+String.format(Locale.US,"%.2f",x));} double d=0; try{d=Double.parseDouble(discount.getText().toString());}catch(Exception e){} double net=Math.max(0,total-d); totalView.setText("মোট: ৳"+String.format(Locale.US,"%.2f",net)); return net; }
    void saveOrder(){ String c=customer.getText().toString().trim(); if(c.isEmpty()){customer.setError("কাস্টমারের নাম দিন"); return;} double net=recalc(); StringBuilder s=new StringBuilder(); String date=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date()); s.append("নবাব Sales\nঅর্ডার: ").append(date).append("\nকাস্টমার: ").append(c).append("\n"); for(ProductRow r:rows){int q=0;try{q=Integer.parseInt(r.qty.getText().toString());}catch(Exception e){} if(q>0)s.append(r.name).append(" × ").append(q).append(" = ৳").append(String.format(Locale.US,"%.2f",q*r.price)).append("\n");} s.append("মোট: ৳").append(String.format(Locale.US,"%.2f",net)); orders.add(0,s.toString()); persist(); new AlertDialog.Builder(this).setTitle("অর্ডার সংরক্ষিত").setMessage(s.toString()).setPositiveButton("Print",(d,w)->printOrder(s.toString())).setNegativeButton("ঠিক আছে",null).show(); }
    void loadOrders(){String all=prefs.getString("orders",""); if(!all.isEmpty()) orders.addAll(Arrays.asList(all.split("\\n---ORDER---\\n")));}
    void persist(){StringBuilder b=new StringBuilder();for(int i=0;i<orders.size();i++){if(i>0)b.append("\n---ORDER---\n");b.append(orders.get(i));}prefs.edit().putString("orders",b.toString()).apply();}
    void showHistory(){base();header("অর্ডার হিস্ট্রি"); ScrollView sv=new ScrollView(this); historyList=new LinearLayout(this); historyList.setOrientation(LinearLayout.VERTICAL); historyList.setPadding(10,10,10,30); if(orders.isEmpty()){emptyHistory=tv("এখনও কোনো অর্ডার নেই।",18); historyList.addView(emptyHistory);} else for(String o:orders){TextView t=tv(o,15);t.setBackgroundColor(Color.WHITE);t.setPadding(14,14,14,14);t.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("Order").setMessage(o).setPositiveButton("Print",(d,w)->printOrder(o)).setNegativeButton("Close",null).show());historyList.addView(t); View line=new View(this);line.setBackgroundColor(0xffdddddd);historyList.addView(line,new LinearLayout.LayoutParams(-1,1));} sv.addView(historyList);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1)); }
    void printOrder(String text){ PrintManager pm=(PrintManager)getSystemService(PRINT_SERVICE); pm.print("Nawab Order",new OrderPrintAdapter(this,text),null); }
    static class OrderPrintAdapter extends PrintDocumentAdapter { final Context c; final String text; PdfDocument pdf; OrderPrintAdapter(Context c,String t){this.c=c;this.text=t;} public void onLayout(PrintAttributes oldA,PrintAttributes newA,CancellationSignal cs,LayoutResultCallback cb,Bundle extras){pdf=new PdfDocument();PdfDocument.PageInfo pi=new PdfDocument.PageInfo.Builder(595,842,1).create();pdf.startPage(pi).getCanvas().drawColor(Color.WHITE);pdf.finishPage(pdf.getPages().get(0));cb.onLayoutFinished(new PrintDocumentInfo.Builder("nawab-order.pdf").setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT).setPageCount(1).build(),true);} public void onWrite(PageRange[] pages,ParcelFileDescriptor dest,CancellationSignal cs,WriteResultCallback cb){try{PdfDocument.Page p=pdf.startPage(new PdfDocument.PageInfo.Builder(595,842,2).create());Canvas cv=p.getCanvas();Paint paint=new Paint();paint.setColor(Color.BLACK);paint.setTextSize(16);int y=45;for(String line:text.split("\\n")){cv.drawText(line,40,y,paint);y+=26;if(y>800)break;}pdf.finishPage(p);pdf.writeTo(new java.io.FileOutputStream(dest.getFileDescriptor()));pdf.close();cb.onWriteFinished(new PageRange[]{PageRange.ALL_PAGES});}catch(Exception e){cb.onWriteFailed(e.toString());}} }
}
